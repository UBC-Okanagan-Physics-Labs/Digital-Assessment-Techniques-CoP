OK_FORMAT = True

test = {   'name': 'Q_tau',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(tau, float)\nTrue', 'failure_message': 'tau must evaluate to a number.', 'hidden': False, 'locked': False, 'points': 0},
                                   {'code': '>>> isinstance(err_tau, float)\nTrue', 'failure_message': 'err_tau must evaluate to a number.', 'hidden': False, 'locked': False, 'points': 0},
                                   {'code': '>>> tau == -1/m\nTrue', 'failure_message': 'Double check your expression for tau.', 'hidden': False, 'locked': False, 'points': 1},
                                   {'code': '>>> err_tau == err_m/m**2\nTrue', 'failure_message': 'Double check your expression for err_tau.', 'hidden': False, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
